import React from 'react'
import classes from './AddNewNotesPage.module.css'

const AddNewNotesPage = () => {
    return (
        <div className={classes.body}>
            
        </div>
    )
}

export default AddNewNotesPage
