import React, { useEffect, useState } from 'react'
import classes from './NotesPage.module.css'
import { BiSearchAlt } from "react-icons/bi";
import { IoMdAddCircle } from "react-icons/io";
import NotesList from './NotesList.js';
import { ModalHeader, Modal, ModalBody, ModalFooter, Button, Input } from 'reactstrap';
import { useDispatch, useSelector } from 'react-redux';
import Select from 'react-select';

const NotesPage = () => {
    const [modaladd, setmodaladd] = useState(false)
    const [title, settitle] = useState("")
    const [subtitle, setsubtitle] = useState("")
    const [image, setimage] = useState("")
    const [button, setbutton] = useState("")
    const [radio, setradio] = useState("")

    const options = [
        { value: 'Archive', label: 'Archive' },
        { value: 'Family', label: 'Family' },
        { value: 'Work', label: 'Work' },
        { value: 'Tasks', label: 'Tasks' },
        { value: 'Priority', label: 'Priority' },
        { value: 'Friends', label: 'Friends' }
    ];
    const handleChange = (selectedOption) => {
        setbutton({ selectedOption });
        console.log(`Option selected:`, selectedOption);
    };

    const dispatch = useDispatch()
    const state = useSelector(state => state.Arraydata)

    const toggleAdd = () => {
        setmodaladd(!modaladd)
    }
    const AddData = () => {
        dispatch({
            type: "ADDData", payload: [{
                id: state[state.length - 1].id + 1,
                Header: title,
                SubHeading: subtitle,
                image: image,
                Button: button?.selectedOption && button.selectedOption.map((d) => { return (d.value) }),
                RButton: radio && [radio]
            }]
        })
        setmodaladd(!modaladd)
        settitle("")
        setsubtitle("")
        setimage("")
        setbutton("")
        setradio("")
    }
    console.log('button', button);


    useEffect(() => {
        dispatch({ type: "CHANGED" })
    }, [])
    return (
        <>

            <div className={classes.body}>
                <div className={classes.search}>
                    <div className={classes.sdiv}>
                        <BiSearchAlt /><  input className={classes.inputsearch} placeholder='Search Notes' />

                    </div>
                    <div className={classes.sbut} onClick={() => { setmodaladd(true) }}>
                        <IoMdAddCircle />&nbsp;&nbsp;New note
                    </div>
                </div>
                <div className={classes.notecont}>
                    <NotesList />
                </div>
            </div>





            {/* modal ADD START*/}



            <Modal isOpen={modaladd} toggle={toggleAdd}>
                <ModalHeader
                    close={<button className="close" onClick={toggleAdd}>×</button>}
                    toggle={toggleAdd}
                >
                    <input placeholder='Title' className={classes.input1} value={title} type="text" onChange={(e) => { settitle(e.target.value) }} />
                </ModalHeader>
                <ModalBody>
                    <textarea placeholder='Find a new company name  ' className={classes.input12} rows="3" cols="60" value={subtitle} type="text" onChange={(e) => { setsubtitle(e.target.value) }} />
                </ModalBody>
                <ModalFooter>
                    <div className={classes.modalbuts}><input placeholder='Image URL' className={classes.modalbutsimg} type="url" value={image} type="url" onChange={(e) => { setimage(e.target.value) }} /></div>
                    <div className={classes.modalbuts}><input placeholder='tasks' className={classes.modalbutsimg} value={radio} type="text" onChange={(e) => { setradio(e.target.value) }} /></div>
                    <div className={classes.modalbuts}>
                        <Select
                            className={classes.multiselect}
                            value={button.selectedOption}
                            onChange={handleChange}
                            options={options}
                            isMulti
                        />
                    </div>
                    {/* <div className={classes.modalbuts}><FiXOctagon /></div> */}
                    <Button
                        color="primary"
                        onClick={AddData}
                    >
                        Save
                    </Button>
                    {' '}
                    <Button onClick={toggleAdd}>
                        Cancel
                    </Button>
                </ModalFooter>
            </Modal>

            {/* modal ADD END*/}



        </>
    )
}

export default NotesPage
