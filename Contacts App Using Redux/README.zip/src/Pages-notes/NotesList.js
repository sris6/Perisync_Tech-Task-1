import React, { useState } from 'react'
import classes from './NotesList.module.css'
import { AiOutlineInfoCircle, AiFillDelete } from "react-icons/ai";
import { useSelector } from 'react-redux';
import { useDispatch } from 'react-redux';
import { ModalHeader, Modal, ModalBody, ModalFooter, Button } from 'reactstrap';
import './NoteList.scss';


const NotesList = () => {

    const [modalview, setmodalview] = useState(false)
    const [dataDetails, setdataDetails] = useState({})

    const toggleview = () => {
        setmodalview(!modalview)
    }

    const openDetails = (data) => {
        setmodalview(true)
        setdataDetails(data)
    }
    const modalclose = () => {
        dispatch({ type: "DELETE", payload: dataDetails.id })
        setmodalview(!modalview)
    }
    const DataNotes = useSelector(state => state.Arraydata)
    const dispatch = useDispatch()
    const list = DataNotes.map((data) => {
        return (
            <>
                <div className={classes.dynamicdiv} >
                    {data.image && <div className={classes.picdiv}><img width="100%" height="100%" src={data.image} /></div>}
                    <div className={classes.heading}>
                        {data.Header && <h2 className={classes.head}>{data.Header}</h2>}
                        {data.SubHeading && <h4 className={classes.head}>{data.SubHeading}</h4>}
                    </div>
                    {data.RButton && <div className={classes.rbutton}>
                        {data.RButton && data.RButton.map((rb) => {
                            return (<div><input className={classes.rbutton1} type="radio" /> {rb} </div>)
                        })}
                    </div>}
                     <div className={classes.bottombutton}>
                        {data.Button && data.Button.map((b) => {
                            return (<div> <button className={classes.buts} >{b}</button> </div>)
                        })}
                        <button className={classes.butsinfodel} onClick={() => { openDetails(data) }}><AiOutlineInfoCircle /></button>
                        <button className={classes.butsinfodel} onClick={() => { dispatch({ type: "DELETE", payload: data.id }) }}><AiFillDelete /></button>
                    </div>
                </div>

            </>
        )
    })

    return (
        <>
            <div className={classes.body}>
                {list}
            </div>

            {/* modal view START*/}
            <Modal isOpen={modalview} toggle={toggleview}>
                <ModalHeader

                >
                    {dataDetails?.image && <div ><img width="100%" height="200px" src={dataDetails?.image} /></div>}
                </ModalHeader>
                <ModalBody>
                    <div className={classes.heading}>
                        {dataDetails?.Header && <h2 className={classes.head}>{dataDetails?.Header}</h2>}
                        {dataDetails?.SubHeading && <h4 className={classes.head}>{dataDetails?.SubHeading}</h4>}
                    </div>

                    {dataDetails?.RButton && <div className={classes.rbutton}>
                        {dataDetails?.RButton && dataDetails?.RButton.map((rb) => {
                            return (<div><input className={classes.rbutton1} type="radio" /> {rb} </div>)
                        })}
                    </div>}
                </ModalBody>
                <ModalFooter>
                    {dataDetails.Button && <div className={classes.bottombutton}>
                        {dataDetails.Button && dataDetails.Button.map((b) => {
                            return (<div> <button className={classes.buts} >{b}</button> </div>)
                        })}
                    </div>}
                    <div className={classes.empty}></div>
                    <Button
                        color="primary"
                        onClick={() => { modalclose() }}
                    >
                        Delete
                    </Button>
                    {' '}
                    <Button onClick={toggleview}>
                        Cancel
                    </Button>
                </ModalFooter>
            </Modal>

            {/* modal view END*/}
        </>
    )
}

export default NotesList
