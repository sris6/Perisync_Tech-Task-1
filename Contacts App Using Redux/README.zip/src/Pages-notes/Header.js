import React, { useState } from 'react'
import classes from './Header.module.css'
import { VscListSelection } from "react-icons/vsc";
import { MdOutlineZoomOutMap } from "react-icons/md";
import { AiOutlineSearch ,AiOutlineMail } from "react-icons/ai";
import { IoPricetagOutline } from "react-icons/io5";
import { FaGlobeAmericas } from "react-icons/fa";
import { Button, Modal, ModalBody, ModalFooter, ModalHeader } from 'reactstrap'

const Header = () => {
    const [timerModal, setTimerModal] = useState(false)

    return (
        <>
        <Modal isOpen={timerModal} toggle={() => setTimerModal(!timerModal)}>
        <ModalHeader >Subskribo</ModalHeader>
        <ModalBody>
          <h5>Are you sure</h5>
          <p>You Want to delete?</p>
        </ModalBody>
        <ModalFooter>
          <Button color='primary' onClick={() => { setTimerModal(!timerModal) }}>
            yes
          </Button>
          <Button color='primary' onClick={() => setTimerModal(!timerModal)}>
            no
          </Button>
        </ModalFooter>
      </Modal>
        <div className={classes.body}>
            <div className={classes.left}>
                <VscListSelection style={{fontSize: '30px' }}/>
            </div>
            <div className={classes.right}>
                <FaGlobeAmericas style={{fontSize: '30px'}}/>
                <MdOutlineZoomOutMap style={{fontSize: '30px' }}/>
                <AiOutlineSearch style={{fontSize: '30px' }}/>
                <IoPricetagOutline style={{fontSize: '30px' }}/>
                <AiOutlineMail style={{fontSize: '30px' }}/>
            </div>
            
        </div>
        </>
    )
}

export default Header
