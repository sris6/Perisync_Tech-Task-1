import React from 'react'
import classes from './SideNavBar.module.css'
import { CgNotes } from "react-icons/cg";
import { BsArchive } from "react-icons/bs";
import { HiOutlineTag } from "react-icons/hi";
import { GrEdit } from "react-icons/gr";

const SideNavBar = () => {
    return (
        <div className={classes.body}>
            <div className={classes.button11}>
                <CgNotes style={{color:'#4f46e5'}} /> &nbsp;&nbsp;Notes
            </div>
            <div className={classes.button1}>
                <BsArchive style={{color:'grey'}} /> &nbsp;&nbsp;Archive
            </div>
            <div className={classes.button1}>
                <HiOutlineTag style={{color:'grey'}}/> &nbsp;&nbsp;Family
            </div>
            <div className={classes.button1}>
                <HiOutlineTag style={{color:'grey'}}/> &nbsp;&nbsp;Work
            </div>
            <div className={classes.button1}>
                <HiOutlineTag style={{color:'grey'}}/> &nbsp;&nbsp;Tasks
            </div>
            <div className={classes.button1}>
                <HiOutlineTag style={{color:'grey'}}/> &nbsp;&nbsp;Priority
            </div>
            <div className={classes.button1}>
                <HiOutlineTag style={{color:'grey'}}/> &nbsp;&nbsp;Friends
            </div>
            <div className={classes.button1}>
                <GrEdit style={{color:'grey'}}/> &nbsp;&nbsp;Edit labels
            </div>
        </div>
    )
}

export default SideNavBar
