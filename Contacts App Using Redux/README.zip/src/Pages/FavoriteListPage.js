import React, { useState } from 'react'
import classes from './FavoriteListPage.module.css'
import DataTable from 'react-data-table-component';
import { AiTwotoneStar, AiFillDelete, AiOutlineInfoCircle } from "react-icons/ai";

const FavoriteListPage = ({ Data, setdata, deleteItem, setdispComponent, setdetails }) => {

    // const [star, setstar] = useState(false)

    const toggleFavorite = (row, index) => {
        setdata( Data.map((s) => (Data.indexOf(s) === index ? {...s, favorite:!s.favorite} : s)))
    }
    let data = Data.filter((d) => {
        return  d.favorite === true;
    })

    const columns = [
        {
            name: '',
            selector: row => {
                return (
                    <div className={classes.images}><img width="100%" height="100%" src={row.image} /></div>
                )
            },
        },
        {
            name: 'FirstName',
            selector: row => row.FirstName,
        },
        {
            name: 'LastName',
            selector: row => row.LastName,
        },
        {
            name: 'Company',
            selector: row => row.Company,
        },
        {
            name: 'JobTitle',
            selector: row => row.JobTitle,
        },
        {
            name: 'Email',
            selector: row => row.Email,
        },
        {
            name: 'Phone',
            selector: row => row.Phone,
        },
        {
            name: '',
            selector: (row, index) => {
                return (
                    <div className={classes.strdel} >
                        {/* <div className={classes.del1} >{!star && <AiTwotoneStar onClick={() => { setstar(true) }} />} {star && <AiTwotoneStar onClick={() => { setstar(false) }} className={classes.del12} />}</div> */}
                        <div className={classes.del1} >{<AiTwotoneStar  className={row.favorite && classes.del12} />}</div>
                        <div className={classes.del2} onClick={() => { deleteItem(index) }}><AiFillDelete /></div>
                        <div className={classes.info} onClick={() => { setdetails(row); setdispComponent("personDetails") }}><AiOutlineInfoCircle /></div>
                    </div>
                )
            },
        },
    ];

    return (
        <DataTable
            columns={columns}
            data={data}
            selectableRows
            pagination
        />
    )
}

export default FavoriteListPage
