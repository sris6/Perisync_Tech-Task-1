import React from 'react'
import classes from './AddContactPage.module.css'
import { IoIosContact,IoIosContacts } from "react-icons/io";
import { BsArrowRepeat } from "react-icons/bs";
import { AiTwotoneStar } from "react-icons/ai";
import { useSelector } from 'react-redux';

const AddContactPage = ({setdispComponent, dispComponent}) => {
    const PassVerify = useSelector(state => state.VerifyPassReduser)
    const loginfo = useSelector(state => state.GetInfoReduser)
    return (
        <div className={classes.addcontacts}>
            <div className={classes.top}>
                <IoIosContact style={{ color: '#777e86', fontSize: '60px', marginLeft: '20px' }} />
                <h3>&nbsp;&nbsp;{loginfo?.fname} {loginfo?.lname}</h3>
            </div>
            <div className={classes.bottom}>
                <div className={classes.newbtn}> <div className={classes.newbtnContact} onClick={() => {setdispComponent("addNew")}}>New Contact</div></div>
                <div className={dispComponent === "table" ? classes.btnhigh : classes.btn} onClick={() => {setdispComponent("table")}}><IoIosContacts style={{ color: '#777e86', fontSize: '20px' }} />&nbsp;&nbsp;All Contacts</div>
                <div className={classes.btn}><BsArrowRepeat style={{ color: '#777e86', fontSize: '20px' }}/>&nbsp;&nbsp;Frequently Contacted</div>
                <div className={dispComponent === "favTable" ? classes.btnhigh : classes.btn} onClick={() => {setdispComponent("favTable")}}><AiTwotoneStar style={{ color: '#777e86', fontSize: '20px' }}/>&nbsp;&nbsp;Starred contacts</div>
            </div>
        </div>
    )
}

export default AddContactPage
