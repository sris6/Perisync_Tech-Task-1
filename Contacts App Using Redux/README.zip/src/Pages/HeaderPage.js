import React from 'react'
import classes from './HeaderPage.module.css'
import { MdOutlineContacts } from "react-icons/md";
import { BiSearchAlt } from "react-icons/bi";

const HeaderPage = ({search,setsearch}) => {
    return (
        <div className={classes.body}>
            <div className={classes.left}>&nbsp;&nbsp;<MdOutlineContacts style={{ color: 'white', fontSize: '30px' }} />&nbsp;&nbsp;Contacts</div>
            <div className={classes.right}>
                <div className={classes.text}>
                    &nbsp;&nbsp;<BiSearchAlt style={{fontSize: '25px' }} />
                    &nbsp;&nbsp;<input className={classes.input} value={search} onChange={(e) => { setsearch(e.target.value)}} placeholder='Search for anything' type="text"></input>
                </div>
            </div>
        </div>


    )
}

export default HeaderPage
