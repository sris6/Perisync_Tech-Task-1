import React, { useState } from 'react'
import classes from './AddNewContactPage.module.css'
import { IoMdContact } from "react-icons/io";
import { ImFilePicture } from "react-icons/im";
import { MdOutlineWork, MdEmail } from "react-icons/md";
import { BsTelephonePlusFill } from "react-icons/bs";
import { ImOffice } from "react-icons/im";

const AddNewContactPage = ({ setdispComponent, setdata, data }) => {

    const [image, setimage] = useState("")
    const [FirstName, setFirstName] = useState("")
    const [LastName, setLastName] = useState("")
    const [Company, setCompany] = useState("")
    const [JobTitle, setJobTitle] = useState("")
    const [Email, setEmail] = useState("")
    const [Phone, setPhone] = useState("")

    const SaveData = () => {
        let v = { image: image, FirstName: FirstName, LastName: LastName, Company: Company, JobTitle: JobTitle , Email: Email, Phone: Phone }
        setdata(data.concat(v))
    }

    return (
        <div className={classes.body}>
            <div className={classes.header}>
                <h2>New Contact</h2>
                <div className={classes.icon}><IoMdContact /></div>
            </div>
            <div className={classes.details}>
                <div className={classes.subdetails}><ImFilePicture style={{ color: "grey" }} />
                    <input placeholder='Enter the Image URL' value={image} onChange={(e) => { setimage(e.target.value) }} type="url" />
                </div>
                <div className={classes.subdetails}><IoMdContact style={{ color: "grey" }} />
                    <input placeholder='First Name' value={FirstName} onChange={(e) => { setFirstName(e.target.value) }} type="text" />
                </div>
                <div className={classes.subdetails}><IoMdContact style={{ color: "grey" }} />
                    <input placeholder='Last Name' value={LastName} onChange={(e) => { setLastName(e.target.value) }} type="text" />
                </div>
                <div className={classes.subdetails}><ImOffice style={{ color: "grey" }} />
                    <input placeholder='Company' value={Company} onChange={(e) => { setCompany(e.target.value) }} type="text" />
                </div>
                <div className={classes.subdetails}><MdOutlineWork style={{ color: "grey" }} />
                    <input placeholder='Job Title' value={JobTitle} onChange={(e) => { setJobTitle(e.target.value) }} type="text" />
                </div>
                <div className={classes.subdetails}><MdEmail style={{ color: "grey" }} />
                <input placeholder='Email' value={Email} onChange={(e) => { setEmail(e.target.value) }} type="email" />
                </div>
                <div className={classes.subdetails}><BsTelephonePlusFill style={{ color: "grey" }} />
                    <input placeholder='Phone' value={Phone} onChange={(e) => { setPhone(e.target.value) }} type="number" />
                </div>
            </div>
            <div className={classes.btns}>
                <buttons className={classes.btn} onClick={() => { setdispComponent("table") }}>Close</buttons>
                <buttons className={classes.btn} onClick={SaveData}>Save</buttons>
            </div>
        </div>
    )
}

export default AddNewContactPage
