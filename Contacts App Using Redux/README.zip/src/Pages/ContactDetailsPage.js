import React from 'react'
import classes from './ContactDetailsPage.module.css'

const ContactDetailsPage = ({ setdispComponent, details }) => {
    console.log(details)
    return (
        <div className={classes.body}>
            <div className={classes.header}>
                <h2>Contact Details</h2>
            </div>
            <div className={classes.content}>
                <div className={classes.imgname}>
                    <div className={classes.imageouter}>
                        <div className={classes.image}>
                            <img className={classes.image} width="100%" height="100%" src={details?.image} />
                        </div>
                    </div>
                    <div className={classes.nameouter}>Name:
                        <div className={classes.name}>{details?.FirstName}{" "}{details?.LastName}</div>
                    </div>
                </div>
                <div className={classes.details}>
                    <div className={classes.subdetails1}>Company Name:
                        <div className={classes.subdetails2}>{details?.Company}</div>
                    </div>
                    <div className={classes.subdetails1}>Job Title:
                        <div className={classes.subdetails2}>{details?.JobTitle}</div>
                    </div>
                    <div className={classes.subdetails1}>Email:
                        <div className={classes.subdetails2}>{details?.Email}</div>
                    </div>
                    <div className={classes.subdetails1}>Phone:
                        <div className={classes.subdetails2}>{details?.Phone}</div>
                    </div>

                </div>
                <div className={classes.btns}>
                    <button className={classes.btn} onClick={() => { setdispComponent("table") }}>Close</button>
                    <button className={classes.btn}>Delete Contact</button>
                </div>
            </div>
        </div>
    )
}

export default ContactDetailsPage
