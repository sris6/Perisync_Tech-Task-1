const ProfileUpdateReduser = (state = "", action) => {
    switch (action.type) {
        case 'PROFILE_UPDATE':
            return action.payload.res.status
        default:
            return state
    }
}
export default ProfileUpdateReduser