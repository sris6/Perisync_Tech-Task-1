const GetGraphReduser = (state = [], action) => {
    switch (action.type) {
        case 'GET_GRAPH':
            return action.payload.res.data
        default:
            return state
    }
}
export default GetGraphReduser