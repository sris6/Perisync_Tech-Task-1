const SidemenuReduser = (state = [], action) => {
    switch (action.type) {
        case 'SIDE_MENU':
            return action.payload.res.data
        default:
            return state
    }
}
export default SidemenuReduser