const LogoutUserReduser = (state = "", action) => {
    switch (action.type) {
        case 'LOG_OUT':
            return action.payload.res.status
        case 'LOG_OUT_FAILED':
            return 200
        default:
            return state
    }
}
export default LogoutUserReduser