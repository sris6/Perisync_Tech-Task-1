
const CheckUserReduser = (state = "", action) => {
    switch (action.type) {
        case 'USER_CHECK':
            return action.payload.res.status
        default:
            return state
    }
}
export default CheckUserReduser