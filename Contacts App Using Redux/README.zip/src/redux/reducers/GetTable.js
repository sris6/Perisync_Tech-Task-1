const GetTableReduser = (state = [], action) => {
    switch (action.type) {
        case 'GET_TABLE':
            return action.payload.res.data
        default:
            return state
    }
}
export default GetTableReduser