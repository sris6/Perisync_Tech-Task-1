import { combineReducers } from 'redux'
import Arraydata from './Arraydata'
import CheckUserReduser from './CheckUser'
import VerifyPassReduser from './VerifyPass'
import LogoutUserReduser from './LogoutUser'
import GetInfoReduser from './GetInfo'
import ImgUploadReduser from './ImgUpload'
import ProfileUpdateReduser from './ProfileUpdate'
import GetTableReduser from './GetTable'
import GetGraphReduser from './GetGraph'
import SidemenuReduser from './Sidemenu'

const rootReducer = combineReducers({
    Arraydata,
    CheckUserReduser,
    VerifyPassReduser,
    LogoutUserReduser,
    GetInfoReduser,
    ImgUploadReduser,
    ProfileUpdateReduser,
    GetTableReduser,
    GetGraphReduser,
    SidemenuReduser
})

export default rootReducer
