const GetInfoReduser = (state = "", action) => {
    switch (action.type) {
        case 'GET_INFO':
            return action.payload.res.data
        case 'PROFILE_UPDATE':
            return action.payload.res.data
            case 'IMG_UPLOAD':
                return {
                    ...state,
                    image: {...state.image, image:action.payload?.res?.data?.imgData}
                }
        default:
            return state
    }
}
export default GetInfoReduser