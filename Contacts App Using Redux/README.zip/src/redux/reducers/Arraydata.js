import {DataNotes} from "../../Components/NotesListArray"

const Arraydata = (state = DataNotes, action) => {
    switch (action.type) {
        case 'CHANGED':
            return state
        case 'DELETE':
            return    state.filter((user) => {
                return user.id !== action.payload;
            });
            case 'ADDData':
            return state.concat(action.payload)
        default:
            return state
    }
}
export default Arraydata