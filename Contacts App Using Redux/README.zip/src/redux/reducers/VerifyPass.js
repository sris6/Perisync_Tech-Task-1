
const VerifyPassReduser = (state = "", action) => {
    switch (action.type) {
        case 'PASSWORD_CHECK':
            return action.payload.res
        case 'LOG_OUT':
            return ''
        case 'LOG_OUT_FAILED':
            return ''
        default:
            return state
    }
}
export default VerifyPassReduser