const ImgUploadReduser = (state = "", action) => {
    switch (action.type) {
        case 'IMG_UPLOAD':
            return action.payload.res.data
        default:
            return state
    }
}
export default ImgUploadReduser