import './App.css';
import './Components/Contacts'
import Contacts from './Components/Contacts';
import Notes from './Components/Notes'
import DTable from './Components/DTable'
import Graph from './Components/Graph';
import ProfileInfo from './Components/ProfileInfo'
import { Route, Switch } from 'react-router-dom';
import MainNav from './Components/MainNav';
import './model.scss';
import LoginPage from '../src/Components/LoginPage';
import SideNavBarMain from "../src/Components/SideNavBarMain"


function App() {
  return (
    <div className='mainnav'>
      {/* <LoginPage/> */}

      <Switch>
        <Route path='/' exact>
          <LoginPage />
        </Route>
        <Route path='/contacts'>
          <MainNav />
          {/* <SideNavBarMain/> */}
          <Contacts />
        </Route>
        <Route path='/notes'>
          <MainNav />
          {/* <SideNavBarMain/> */}
          <Notes />
        </Route>
        <Route path='/DTable'>
          <MainNav />
          {/* <SideNavBarMain/> */}
          <DTable />
        </Route>
        <Route path='/Graph'>
          <MainNav />
          {/* <SideNavBarMain/> */}
          <Graph />
        </Route>
        <Route path='/ProfileInfo'>
          <MainNav />
          {/* <SideNavBarMain/> */}
          <ProfileInfo/>
        </Route>
      </Switch>
    </div>
  );
}
export default App;
