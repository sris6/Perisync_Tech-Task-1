import React from 'react'
import classes from './Graph.module.css'
import { connect, useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { Bar } from 'react-chartjs-2'
import { Card, CardHeader, CardTitle, CardBody } from 'reactstrap';
import {GetGraphSession} from '../api/ApiCall';

const Graph = ({ tooltipShadow, gridLineColor, labelColor, successColorShade }) => {

    const GraphGet = useSelector(state => state.GetGraphReduser)
    console.log(GraphGet)
    
    const dispatch = useDispatch()
    useEffect(() => {
        dispatch(GetGraphSession({ token: localStorage.getItem('token'), userid: localStorage.getItem('userid') }))
    }, [])


    const options = {
        elements: {
            rectangle: {
                borderWidth: 2,
                borderSkipped: 'bottom'
            }
        },
        responsive: true,
        maintainAspectRatio: false,
        responsiveAnimationDuration: 500,
        legend: {
            display: false
        },
        tooltips: {
            // Updated default tooltip UI
            shadowOffsetX: 1,
            shadowOffsetY: 1,
            shadowBlur: 8,
            shadowColor: tooltipShadow,
            backgroundColor: '#fff',
            titleFontColor: '#000',
            bodyFontColor: '#000'
        },
        scales: {
            xAxes: [
                {
                    display: true,
                    gridLines: {
                        display: true,
                        color: gridLineColor,
                        zeroLineColor: gridLineColor
                    },
                    scaleLabel: {
                        display: false
                    },
                    ticks: {
                        fontColor: labelColor
                    }
                }
            ],
            yAxes: [
                {
                    display: true,
                    gridLines: {
                        color: gridLineColor,
                        zeroLineColor: gridLineColor
                    },
                    ticks: {
                        stepSize: 100,
                        min: 0,
                        max: 400,
                        fontColor: labelColor
                    }
                }
            ]
        }
    },
        data = {
            labels: GraphGet?.x_axis_start,
            datasets: [
                {
                    data: GraphGet?.values,
                    backgroundColor: successColorShade,
                    borderColor: 'transparent',
                    barThickness: 40
                }
            ]
        }

    return (
        <div className={classes.body}>
            <Card>
                <CardHeader className='d-flex justify-content-between align-items-sm-center align-items-start flex-sm-row flex-column'>
                    <CardTitle tag='h4'><span>water consumed-</span>{GraphGet?.water_consumed} &nbsp;&nbsp;&nbsp;&nbsp;<span>water charges-</span>{GraphGet?.water_charges}</CardTitle>
                </CardHeader>
                <CardBody>
                    <div style={{ height: '800px' }, { width: '800px' }}>
                        <Bar data={data} options={options} height={400} />
                    </div>
                </CardBody>
            </Card>
        </div>
    )
}

export default Graph
