import React, { useEffect, useState } from 'react'
import classes from './Contacts.module.css'
import SideNav from '../Pages/AddContactPage'
import HeaderPage from '../Pages/HeaderPage'
import ContactListPage from '../Pages/ContactListPage'
import ContactDetailsPage from '../Pages/ContactDetailsPage'
import AddNewContactPage from '../Pages/AddNewContactPage'
import {Data} from './ContactsListArray'
import FavoriteListPage from '../Pages/FavoriteListPage'
import { useSelector } from 'react-redux'
import { useHistory } from 'react-router'

const Contacts = () => {
    const [data, setdata] = useState(Data)

    const [dispComponent, setdispComponent] = useState("table")

    const [details, setdetails] = useState(null)

    const [search, setsearch] = useState("")

    const deleteItem = (index) => {
        setdata(data.filter((d, i) => {
            return(index != i)
        }))
    }
    const PassVerify = useSelector(state => state.VerifyPassReduser)
    const history = useHistory()
    // useEffect(() => {
    //     if (PassVerify?.status !== 200) {
    //         ("/")
    //     }
    // }, [PassVerify])
    return (
        <div className={classes.body}>
            <div className={classes.header} >
            <HeaderPage search={search} setsearch={setsearch}/>
            </div>
            <div className={classes.content}>
                <div className={classes.newcontact}>
                    <SideNav setdispComponent={setdispComponent} dispComponent={dispComponent}/>
                </div>
                <div className={classes.contactlist}>
                    {dispComponent === "table" && <ContactListPage Data={data} setdata={setdata}  deleteItem={deleteItem} setdispComponent={setdispComponent} setdetails={setdetails} search={search}/>}
                    {dispComponent === "personDetails" && <ContactDetailsPage setdispComponent={setdispComponent} details={details}/>}
                    {dispComponent === "addNew" && <AddNewContactPage setdispComponent={setdispComponent} setdata={setdata} data={data}/> }
                    {dispComponent === "favTable" && <FavoriteListPage Data={data} setdata={setdata}  deleteItem={deleteItem} setdispComponent={setdispComponent} setdetails={setdetails}/>}

                </div>
            </div>
        </div>
    )
}

export default Contacts
