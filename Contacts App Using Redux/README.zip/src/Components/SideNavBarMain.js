import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import { Link, Route, Switch } from 'react-router-dom';
import * as FaIcons from 'react-icons/fa';
import * as AiIcons from 'react-icons/ai';
// import { SidebarData } from './SidebarData';
import SubMenu from '../Components/SubMenu';
import { IconContext } from 'react-icons/lib';
import axios from 'axios';
import { useHistory } from 'react-router-dom';
import { SidemenuAPI } from '../api/ApiCall';
// import { Classes } from 'SideNavBarMain.module.css';
// import Profile from '../Profile';

const Nav = styled.div`
  background:#082c66;
  width: 200px;
  height: 80px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
`;

const NavIcon = styled(Link)`
  margin-left: 2rem;
  font-size: 2rem;
  height: 80px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
`;

const SidebarNav = styled.nav`
  background: #082c66;
  width: 250px;
  height: 100vh;
  display: flex;
  justify-content: center;
  position: fixed;
  top: 0;
  colour:#fff
  left: ${({ sidebar }) => (sidebar ? '0' : '-100%')};
  transition: 350ms;
  z-index: 10;
`;

const SidebarWrap = styled.div`
width: 250px;
`;

const Sidebar = () => {


  const [sidebar, setSidebar] = useState(true);
  const [sideMenuData, setsideMenuData] = useState([])
  const showSidebar = () => setSidebar(!sidebar);
  const history = useHistory();

const body = {
  type:'WEB',
  token:localStorage.getItem("token"),
  userid:localStorage.getItem("userid"),
  roleid:parseInt(localStorage.getItem("roleid"))

}
const sidemenu = () => {
axios.put('https://api.perisync.com/show/menuByRoleID',body).then((response) => {
  setsideMenuData(response.data);
  console.log(response);
});
}
useEffect(() => {
  sidemenu();
      }, [])

  return (
    <>
      <IconContext.Provider value={{ color: '#fff' }}>
        <Nav>
          <NavIcon to='#'>
            <FaIcons.FaBars onClick={showSidebar} />
          </NavIcon>
        </Nav>
        <SidebarNav sidebar={sidebar}>
          <SidebarWrap>
            <NavIcon to='#fff'>
              <FaIcons.FaBars onClick={()=>{showSidebar()}}/>
            </NavIcon>
            {sideMenuData.map((item, index) => {
              return <SubMenu item={item} key={index} />;
            })}
          </SidebarWrap>
        </SidebarNav>
      </IconContext.Provider>
    </>
  );
};

export default Sidebar;