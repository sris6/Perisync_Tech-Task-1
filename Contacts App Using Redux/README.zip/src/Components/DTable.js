import React, { useEffect } from 'react'
import classes from './DTable.module.css'
import DataTable from 'react-data-table-component';
import { GetTableSession } from '../api/ApiCall'
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';


const DTable = () => {
  const data = useSelector(state => state.GetTableReduser)
  const dispatch = useDispatch()
   useEffect(() => {
    dispatch(GetTableSession({token: localStorage.getItem('token'),  userid: localStorage.getItem('userid') }))
   }, [])

  const columns = [
    {
        name: 'userid',
        selector: row => row.userid,
    },
    {
        name: 'jid',
        selector: row => row.jid,
    },
    {
        name: 'sub',
        selector: row => row.sub,
    },
    {
        name: 'issuedat',
        selector: row => row.issuedat,
    },
    {
        name: 'expiresat',
        selector: row => row.expiresat,
    },
    {
        name: 'Platform',
        selector: row => row.Platform,
    },
];

  return (
    <div className={classes.body}>
        <div className={classes.table}>
      <DataTable className={classes.table1}
            columns={columns}
            data={data}
            selectableRows
            pagination
        />
        </div>
    </div>
  )
}

export default DTable
