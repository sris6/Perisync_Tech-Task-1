import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { ProfileUpdate, ImgUploadApi } from '../api/ApiCall'
import classes from './ProfileInfo.module.css'
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const ProfileInfo = () => {
    const loginfo = useSelector(state => state.GetInfoReduser)

    const ImgUploadRed = useSelector(state => state.ImgUploadReduser)

    const [image, setimage] = useState("")

    const [editState, seteditState] = useState(false)

    const [ProfileUpdatestate, setProfileUpdatestate] = useState({})

    const dispatch = useDispatch()

    const ImgUpload = () => {
        let formData = new FormData();
        formData.append('snapshot', image);
        formData.append('userid', localStorage.getItem('userid'));
        formData.append('token', localStorage.getItem('token'));
        setTimeout(() => {
            dispatch(ImgUploadApi(formData))
        }, 500);
    }

    const UpdateProfile = () =>{
        dispatch(ProfileUpdate({...ProfileUpdatestate ,token: localStorage.getItem('token'),  userid: localStorage.getItem('userid') }))
        seteditState(false)
    }



    useEffect(() => {
        setimage("")
        setProfileUpdatestate(loginfo)
    }, [loginfo])
    console.log(ProfileUpdatestate);

    return (
        <>
        <ToastContainer />
            <div className={classes.body}>
                <div className={classes.imgname} >

                    <div className={classes.img}><img className={classes.img} width='100' height='100' src={`${"data:image/png;base64," + loginfo?.image?.image}`} /></div>
                    <div className={classes.name}><span className={classes.head}>First Name :&nbsp;</span> 
                    { !editState ? loginfo?.fname : <input className={classes.inp} value={ProfileUpdatestate?.fname} type="text" 

                    onChange={(e) => (setProfileUpdatestate({ ...ProfileUpdatestate, fname: e.target.value }))}
                    
                    ></input>}</div>
                    <div className={classes.name}><span className={classes.head}>Last Name : &nbsp;</span>
                    { !editState ? loginfo?.lname : <input className={classes.inp} value={ProfileUpdatestate?.lname} type="text"

                    onChange={(e) => (setProfileUpdatestate({ ...ProfileUpdatestate, lname: e.target.value }))}

                    ></input>}</div>
                </div>
                <div className={classes.addimage}>
                    <div>
                    <input className={classes.ipbuts} type="file" onChange={(e) => { setimage(e.target.files[0]) }}></input>
                    {image &&
                    <button className={classes.buts} onClick={() => { ImgUpload() }}>Upload</button>}
                    </div>
                    <div> 
                        { !editState ? 
                        <button className={classes.butsedit} onClick={() => { seteditState(true) }}>Edit</button> :
                        <div> 
                        <button className={classes.butsedit} onClick={() => { UpdateProfile() }}>Save</button>
                        <button className={classes.butsedit} onClick={() => { seteditState(false) }}>Cancel</button>
                        </div>
                        }
                    </div>
                </div>
                <div className={classes.otherdetails}>
                    <div className={classes.details}><span className={classes.head}>Mobile Number : &nbsp;</span>
                    { !editState ? loginfo?.mobile1: <input value={ProfileUpdatestate?.mobile1} type="number"

                    onChange={(e) => (setProfileUpdatestate({ ...ProfileUpdatestate, mobile1: e.target.value }))}

                    ></input>}</div>
                    <div className={classes.details}><span className={classes.head}>Email : &nbsp;</span>{loginfo?.email}</div>
                    <div className={classes.details}><span className={classes.head}>Address 1 : &nbsp;</span>
                    { !editState ? loginfo?.address1 : <input value={ProfileUpdatestate?.address1} type="text"
                    
                    onChange={(e) => (setProfileUpdatestate({ ...ProfileUpdatestate, address1: e.target.value }))}
                    
                    ></input>}</div>
                    <div className={classes.details}><span className={classes.head}>Created Date : &nbsp;</span>{loginfo?.createddate}</div>
                    <div className={classes.details}><span className={classes.head}>DOB : &nbsp;</span>
                    { !editState ? loginfo?.dob : <input value={ProfileUpdatestate?.dob} type="text"
                    
                    onChange={(e) => (setProfileUpdatestate({ ...ProfileUpdatestate, dob: e.target.value }))}
                    
                    ></input>}</div>
                    <div className={classes.details}><span className={classes.head}>language : &nbsp;</span>{loginfo?.language?.language_name}</div>
                </div>
            </div>
        </>
    )
}

export default ProfileInfo
