export const DataNotes=[
{ 
    id:1,
    image: "https://images.unsplash.com/photo-1453728013993-6d66e9c9123a?ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8dmlld3xlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&w=1000&q=80",
    Header:'Find a company name',
    Button:['Work','tasks']
},
{ 
    id:2,
    image: "https://st2.depositphotos.com/1105977/5461/i/600/depositphotos_54615585-stock-photo-old-books-on-wooden-table.jpg",
    SubHeading:'Shoping list',
    RButton : ['bread','milk','onion','coffe','toilet paper'],
    Button:['tasks','Work']
},
{ 
    id:3,
    image: "https://images.ctfassets.net/hrltx12pl8hq/3MbF54EhWUhsXunc5Keueb/60774fbbff86e6bf6776f1e17a8016b4/04-nature_721703848.jpg?fit=fill&w=480&h=270",
    Header:'send the photos of last summer',
    Button:['personal','task'],
},
{ 
    id:4,
    SubHeading:'Shoping list',
    RButton : ['breakfast','opening ceremony','lunch break'],
    Button:['personal','tasks','work',],
},
{ 
    id:5,
    image: "https://cdn.pixabay.com/photo/2021/08/25/20/42/field-6574455__480.jpg",
    Header:'send the photos of last summer',
    Button:['personal','task'],
},

];