import React, { useEffect, useState } from 'react'
import classes from './Notes.module.css'
import Header from '../Pages-notes/Header'
import SideNavBar from '../Pages-notes/SideNavBar'
import NotesPage from '../Pages-notes/NotesPage'
import { useSelector } from 'react-redux'
import { useHistory } from 'react-router'



const Notes = () => {
    const PassVerify = useSelector(state => state.VerifyPassReduser)
    const history = useHistory()
    // useEffect(() => {
    //     if (PassVerify?.status !== 200) {
    //         history.push("/")
    //     }
    // }, [PassVerify])
    return (
        <>
        
        <div className={classes.body}>
            <div className={classes.header} >
                <Header />
            </div>
            <div className={classes.content} >
                <div className={classes.sidenavbar} >
                    <SideNavBar />
                </div>
                <div className={classes.notespage} >
                    <NotesPage />
                </div>
            </div>
        </div>
        </>
    )
}

export default Notes
