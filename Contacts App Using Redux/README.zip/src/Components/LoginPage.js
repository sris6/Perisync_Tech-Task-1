import React from 'react'
import classes from './LoginPage.module.css'
import { connect, useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { UserCheck, PasswordVerify } from '../api/ApiCall';
import { useHistory } from 'react-router';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


const LoginPage = () => {
    const state = useSelector(state => state.CheckUserReduser)
    const PassVerify = useSelector(state => state.VerifyPassReduser)
    const history = useHistory()

    const [details, setDetails] = useState({
        email: "",
        password: "",
    });
    console.log(PassVerify);

    const dispatch = useDispatch()
    const checkUser = () => {
        dispatch(UserCheck(details))
    }
    const login = () => {
        dispatch(PasswordVerify(details))
    }

    useEffect(() => {
        if (PassVerify?.status === 200) {
            history.push("/contacts")
        }
    }, [PassVerify])

    console.log("Data");

    return (
        <>
         <ToastContainer />
            <div className={classes.body}>
                <div className={classes.left}>
                </div>
                <div className={classes.right}>
                    {state === 200 ?
                        <div className={classes.logincontent}>
                            <div className={classes.logincredncial}>Email
                                <input className={classes.inputtag} placeholder="joy@google.com" value={details.email} type="text"  />
                            </div>
                            <div className={classes.logincredncial}>Password
                                <input className={classes.inputtag} value={details.password}
                                    placeholder="pass"
                                    onChange={(e) => (
                                        setDetails({ ...details, password: e.target.value })
                                    )} />
                            </div>
                            <div className={classes.empty}></div>
                            <div className={classes.buttons}>
                                <button className={classes.but}>forgot password </button>
                                <button className={classes.but} onClick={() => { login() }}>login</button>
                            </div>
                        </div> :
                        <div className={classes.logincontent}>
                            <div className={classes.logincredncial}>Email
                                <input className={classes.inputtag} placeholder="joy@google.com" value={details.email} type="text" onChange={(e) => (
                                    setDetails({ ...details, email: e.target.value })
                                )} />
                            </div>
                            <div className={classes.empty}></div>
                            <div className={classes.buttons}>
                                <button className={classes.but}>forgot password </button>
                                <button className={classes.but} onClick={() => { checkUser() }}>checkUser</button>
                            </div>
                        </div>

                    }
                </div>
            </div>
        </>
    )
}
export default LoginPage