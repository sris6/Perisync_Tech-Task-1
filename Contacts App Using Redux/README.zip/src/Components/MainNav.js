import React from 'react'
import { Link } from 'react-router-dom'
import classes from './MainNav.module.css'
import { getinfoApi, logoutApi, SidemenuAPI } from '../api/ApiCall';
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { useHistory } from 'react-router';

const MainNav = () => {
    const state = useSelector(state => state.LogoutUserReduser)
    const PassVerify = useSelector(state => state.VerifyPassReduser)
    const loginfo = useSelector(state => state.GetInfoReduser)
    const menuside = useSelector(state => state.SidemenuReduser)
    console.log(menuside);

    const history = useHistory()

    const dispatch = useDispatch()
    const Logout = () => {
       setTimeout(() => {
        history.push("/")
       }, 100);
        dispatch(logoutApi({ access_token: localStorage.getItem('token'), userid: localStorage.getItem('userid'), refresh_token: localStorage.getItem('refresh_token') }))
    }
    // useEffect(() => {
    //     if (state === 200) {
    //         history.push("/")
    //     }
    // }, [state])

    useEffect(() => {
        dispatch(getinfoApi({ token: localStorage.getItem('token'), userid: localStorage.getItem('userid') }))
    }, [])


    useEffect(() => {
        dispatch(SidemenuAPI({ token: localStorage.getItem('token'), userid: localStorage.getItem('userid') }))
    }, [])

    return (
        <div className={classes.maindiv}>
            <div className={classes.divs}></div>
            <div className={classes.profilepic}> <img className={classes.profilepic} width='100' height='100' src={`${"data:image/png;base64," +   loginfo?.image?.image}`} /></div>
            <div className={classes.divs}></div>
            <div className={classes.divs}>
                <h1>Hi&nbsp;{loginfo?.fname} {loginfo?.lname}</h1>
            </div>
            <div className={classes.divs}></div>

            <div className={classes.divs1}>
                <Link className={classes.links} to='/contacts'>Contacts</Link>
            </div>
            <div className={classes.divs1}>
                <Link className={classes.links} to='/Notes'>Notes</Link>
            </div>
            <div className={classes.divs1}>
                <Link className={classes.links} to='/dtable'>Data Table</Link>
            </div>
            <div className={classes.divs1}>
                <Link className={classes.links} to='/graph'>Graph</Link>
            </div>
            <div className={classes.profile}>
                <Link className={classes.links} to='/ProfileInfo'>Profile Info</Link>
            </div>
            <div className={classes.logout} onClick={() => { Logout() }}>Log out</div>
        </div>
    )
}

export default MainNav
