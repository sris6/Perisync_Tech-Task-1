export const Data = [
  {
    image: "https://images.unsplash.com/photo-1453728013993-6d66e9c9123a?ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8dmlld3xlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&w=1000&q=80",
    FirstName: "Abbot",
    LastName: "keitch",
    Company: "saois",
    JobTitle: "Digital Archivist",
    Email: "abbott@withinpixels.com",
    Phone: "+1-202-555-0175",
    favorite: true,
    id:1
  },
  {
    image: "https://images.ctfassets.net/hrltx12pl8hq/3MbF54EhWUhsXunc5Keueb/60774fbbff86e6bf6776f1e17a8016b4/04-nature_721703848.jpg?fit=fill&w=480&h=270",
    FirstName: "Arnold",
    LastName: "Matlock",
    Company: "laotcone",
    JobTitle: "Graphic Artist",
    Email: "arnold@withinpixels.com",
    Phone: "+1-202-555-0175",
    favorite: false
  },
  {
    image: "https://images.unsplash.com/photo-1503023345310-bd7c1de61c7d?ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8aHVtYW58ZW58MHx8MHx8&ixlib=rb-1.2.1&w=1000&q=80",
    FirstName: "Barrera",
    LastName: "bradbury",
    Company: "unizim",
    JobTitle: "Graphic Designer",
    Email: "barrera@withinpixels.com",
    Phone: "+1-202-555-0175",
    favorite: true
  },
  {
    image: "https://cloudfront-us-east-2.images.arcpublishing.com/reuters/F6INOOMSRRL5XOOQDRPZUWPWBA.jpg",
    FirstName: "Mohammed",
    LastName: "Mustafa",
    Company: "perisync",
    JobTitle: "frontend devloper",
    Email: "mustafa@perisync.com",
    Phone: "+1-202-555-0175",
    favorite: false
  },
  {
    image: "https://st2.depositphotos.com/1105977/5461/i/600/depositphotos_54615585-stock-photo-old-books-on-wooden-table.jpg",
    FirstName: "Mohammed",
    LastName: "Mukheem",
    Company: "perisync",
    JobTitle: "frontend devloper",
    Email: "mustafa@perisync.com",
    Phone: "+1-202-555-0175",
    favorite: false
  },
  {
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR3Ne4fxlOxhGDTycjkVZd_4KxtraQ0WP4DoQ&usqp=CAU",
    FirstName: "Abbot",
    LastName: "keitch",
    Company: "saois",
    JobTitle: "Digital Archivist",
    Email: "abbott@withinpixels.com",
    Phone: "+1-202-555-0175",
    favorite: false
  },
  {
    image: "https://images.unsplash.com/photo-1453728013993-6d66e9c9123a?ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8dmlld3xlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&w=1000&q=80",
    FirstName: "Abbot",
    LastName: "keitch",
    Company: "saois",
    JobTitle: "Digital Archivist",
    Email: "abbott@withinpixels.com",
    Phone: "+1-202-555-0175",
    favorite: false
  },
  {
    image: "https://images.ctfassets.net/hrltx12pl8hq/3MbF54EhWUhsXunc5Keueb/60774fbbff86e6bf6776f1e17a8016b4/04-nature_721703848.jpg?fit=fill&w=480&h=270",
    FirstName: "Arnold",
    LastName: "Matlock",
    Company: "laotcone",
    JobTitle: "Graphic Artist",
    Email: "arnold@withinpixels.com",
    Phone: "+1-202-555-0175",
    favorite: false
  },
 
]